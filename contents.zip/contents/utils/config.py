VERSIONS_LAUNCHER = '1.4.1'

minecraft_directory = r"C:\.stoneworld\SWMinecraft"
CREATE_NO_WINDOW = 0x08000000

version_optifine = {
    '1.7.10': ['https://ru-minecraft.ru/engine/download.php?id=38581', 'optifine_1.7.10_hd_u_e7.jar'],
    '1.8.9': ['https://ru-minecraft.ru/engine/download.php?id=84559', 'optifine_1.8.9_hd_u_m5.jar'],
    '1.9.4': ['https://ru-minecraft.ru/engine/download.php?id=84560', 'optifine_1.9.4_hd_u_i5.jar'],
    '1.10.2': ['https://ru-minecraft.ru/engine/download.php?id=84561', 'optifine_1.10.2_hd_u_i5.jar'],
    '1.11.2': ['https://ru-minecraft.ru/engine/download.php?id=84562', 'optifine_1.11.2_hd_u_g5.jar'],
    '1.12.2': ['https://ru-minecraft.ru/engine/download.php?id=84565', 'optifine_1.12.2_hd_u_g5.jar'],
    '1.20.1': ['https://ru-minecraft.ru/engine/download.php?id=175178', 'optifine_1.20.1_hd_u_i6.jar'],
    '1.20.2': ['https://ru-minecraft.ru/engine/download.php?id=175176', 'optifine_1.20.2_hd_u_i7_pre1.jar'],
    '1.20.4': ['https://ru-minecraft.ru/engine/download.php?id=184661', 'optifine_1.20.4_hd_u_i8_pre4.jar']
}