import os
import shutil
import winshell
import eel
import subprocess

from win32com.client import Dispatch
from db.data import update_last_version_launcher

# Проверка что exe в C:\.stoneworld\
def tags_stonelauncher():
    if os.path.exists(r"./SLauncher.exe"):
        if os.path.exists(r"C:\.stoneworld\SLauncher.exe"):
            return False
        else:
            return True
        
def tags_slu():
    if os.path.exists(r"C:\.stoneworld\update\SLUpdate.exe"):
        return False
    else:
        return True
    
def tags_sltg():
    if os.path.exists(r"C:\.stoneworld\update\SLTimeGame.exe"):
        return False
    else:
        return True
    
@eel.expose
def tags_stonelauncher_init():
    shutil.move(r"./SLauncher.exe", r"C:\.stoneworld")
    desktop = winshell.desktop()
    path = os.path.join(desktop, r"SLauncher.lnk")
    target = r"C:\.stoneworld\SLauncher.exe"
    wDir = r"C:\.stoneworld"
    icon = r"C:\.stoneworld\SLauncher.exe,0"

    shell = Dispatch('WScript.Shell')
    shortcut = shell.CreateShortCut(path)
    shortcut.Targetpath = target
    shortcut.WorkingDirectory = wDir
    shortcut.IconLocation = icon
    shortcut.save()
    return True


@eel.expose
def end_update_launcher():
    update_last_version_launcher()
    subprocess.Popen(r"C:\.stoneworld\update\SLUpdate.exe")