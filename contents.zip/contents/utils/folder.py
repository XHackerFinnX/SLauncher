import os
import subprocess
import zipfile
import eel

from utils.config import minecraft_directory


def createFolder(path):
    if not os.path.exists(path):
        os.mkdir(path)
    return

def download_dir():
    path = r"C:\Users\.."
    path_sw = r"C:\.stoneworld"
    projectname = ".stoneworld"
    minecraft_dir = "SWMinecraft"
    db = "db"
    update_exe = 'update'

    fullPath = os.path.join(path, projectname)
    fullpathsw = os.path.join(path_sw, minecraft_dir)
    fullpathdb = os.path.join(path_sw, db)
    fullpathupdate = os.path.join(path_sw, update_exe)
    createFolder(fullPath)
    createFolder(fullpathsw)
    createFolder(fullpathdb)
    createFolder(fullpathupdate)
    
def add_mods(path):
    mods = 'mods'
    fullPath = os.path.join(path, mods)
    createFolder(fullPath)
    
def add_resourcepacks(path):
    resour = 'resourcepacks'
    fullPath = os.path.join(path, resour)
    createFolder(fullPath)
    
def download_java():
    try:
        subprocess.check_call(['java', '-version'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return False
    except subprocess.CalledProcessError:
        return True
    except:
        return True


def zip_unzip(url ,name_file):
    unzip = url
    file_zip = zipfile.ZipFile(f"C:\\.stoneworld\\SWMinecraft\\{name_file}", 'r')
    for f in file_zip.namelist():
        full = os.path.join(unzip, f)
        d = os.path.dirname(full)
        if d:
            if not os.path.exists(d):
                os.makedirs(d)
        if os.path.basename(f):
            out = open(full, mode="wb")
            out.write(file_zip.read(f))
            out.close()
    file_zip.close()
    return

@eel.expose
def open_folder_version(version):
    path = minecraft_directory + f"\\{version}"
    subprocess.run(['explorer', path])